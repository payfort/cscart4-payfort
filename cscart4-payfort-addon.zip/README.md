# PayFort FORT plugin for CS-Cart (4.0.0)+

Please set the following values in the Payfort merchant settings:

Return Url: [yout_site_domain]/index.php?dispatch=payment_notification.return&payment=payfort_fort

## Installation

To Install plugin please open your administration panel and go to Add-ons → Manage add-ons.

click on the plus sigin(+) on the top right
click on local and Choose cscart4-payfort.zip file
click on upload & install

## Configuration

go to installed add-ons and choose PayFort FORT addon click on it and fill the merchant info and click save

To add a payment method : 
open your administration panel and go to Payment methods 

Click on the plus sigin(+) on the top right
Fill the name you want to display as payment method
choose the Processor (PayFort Credit Card , PayFort Sadad or PayFort Naps);
Then click on create.

Copyright (c) Payfort

is released under the [MIT License](LICENSE).


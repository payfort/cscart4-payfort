<?php
if (!defined('BOOTSTRAP')) { die('Access denied'); }

//
// Defined variables
//
define('PAYFORT_FORT_GATEWAY_HOST', 'https://checkout.payfort.com/');
define('PAYFORT_FORT_GATEWAY_SANDBOX_HOST', 'https://sbcheckout.payfort.com/');